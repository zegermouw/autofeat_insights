
def get_title(string):
    return "string:" + string