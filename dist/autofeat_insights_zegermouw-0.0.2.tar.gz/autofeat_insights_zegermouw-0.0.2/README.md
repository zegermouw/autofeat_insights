# Package for Autofeat insights

This library contains the functions for insights in the AutoFeat Algorithm

